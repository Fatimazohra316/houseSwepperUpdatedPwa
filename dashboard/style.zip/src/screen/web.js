import axios from "axios";
import React, { useEffect, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import image1 from "../images/purpleHand.png";
import image2 from "../images/view.png";
import image3 from "../images/rating.png";
import image4 from "../images/rating4.PNG";
import image5 from "../images/rating3.PNG";
import image6 from "../images/rating2.PNG";
import image7 from "../images/rating1.PNG";
import { FamilyRestroomTwoTone } from "@mui/icons-material";



function Web() {
    return (<>
        <p>heelo</p>
    </>)
}



export default Web;